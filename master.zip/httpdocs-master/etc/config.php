<?php

if ($_SERVER["SERVER_ADDR"] == "87.250.153.86") {

    define("DATABASE_HOST", "localhost");
    define("DATABASE_USER", "irismaster_www");
    define("DATABASE_PASS", "Nzzr73$9");
    define("DATABASE_NAME", "irismaster_www");

    define("DATABASE_USER_IRIS", "irismaster_iris");
    define("DATABASE_PASS_IRIS", "Nzzr73$9");
    define("DATABASE_NAME_IRIS", "irismaster_iris");
}else{
    define("DATABASE_HOST", "localhost");

    define("DATABASE_USER_IRIS", "root");
    define("DATABASE_PASS_IRIS", "root");
    define("DATABASE_NAME_IRIS", "iris");


    define("DATABASE_USER", "root");
    define("DATABASE_PASS", "root");
    define("DATABASE_NAME", "www");

}


define("FTP_HOST","irismaster.cdn-tmo.nl");
define("FTP_NAME","irismaster");
define("FTP_PASS","Nzzr73$9");
define("CDNROOT","http://master.dev-tmo.nl");

define("IRISROOT","../iris");
define("IRIS_SSL",false);

define("WWWROOT","../httpdocs");
define("WWW_SSL",false);

define("PASSWORD_SALT","2982rih2in3cy3689tvnty4n8q93tn7q3498583");


/* ERROR */
define("CACHE",false);
define("ERROR_DEBUG_SCREEN", true);
define("ERROR_DEBUG_MAIL", false);
define("ERROR_DEBUG_SQL", true);
define("ERROR_MAILTO", "mdierks@themindoffice.nl");

/* ENGINE */
define("UPLOAD_PATH","slir/KMEM783SL");
define("APPLET_BOUNDARY", "@");

/* MAIL */
define("FROM_NAME","The MindOffice");
define("FROM_EMAIL","info@themindoffice.nl");

define("MAIL_HOST","smtp.mandrillapp.com");
define("MAIL_USER","dvanoverdijk@themindoffice.nl");
define("MAIL_PASS","QEOvQaVRVMEI58WryPWvwQ");
define("MAIL_API","NJ81G2SslKV45HCC6QAgkw");

/* API KEYS */
define("IPINFODB","6b59cbd7896949c7fbe022462944c356d8f5013b762471d827682c4819d8cbc3");

define("DBIP", "fd2365edb820b142fd06157639ba7c9a5a8cf170");

define("GO_SITE_KEY","6LcnyxATAAAAAJuDmbwCkyVZ5Kd6OJsBl-gawIIb");
define("GO_SECRET_KEY","6LcnyxATAAAAAK2AhOjVPaIF78z1F4EIrMnH9ji_");

define("GOOGLE_KEY","AIzaSyBzix3-n6xl5n44g66Mf2P_bw9UlOpJ0pw");


                ?>
