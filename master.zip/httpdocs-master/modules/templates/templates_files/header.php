<?php global $argseo?><!doctype html>
<html lang="en">
    <head id="seo">
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title><?php echo output($argseo["page_title"])?></title>
    <meta name="description" content="<?php echo output($argseo["page_decription"])?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="manifest" href="site.webmanifest">
    <link rel="apple-touch-icon" href="icon.png">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="/dist/custom.css">
</head>

<body>
  <header>This is where the header lives {{template.telefoonnummer}}</header>
