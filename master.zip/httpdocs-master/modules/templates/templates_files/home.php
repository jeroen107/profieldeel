<?php include("header.php")?>

      <section class="jumbotron text-center"  style="background-size:cover;background-position:center center" v-bind:style="{ 'background-image': 'url(' + page.header + ')' }">
        <div class="container">
          <h1 class="jumbotron-heading">{{page.titel}}</h1>
          <p class="lead text-muted">{{page.subtitel}}</p>
          <p>
            <a href="#" class="btn btn-primary my-2">{{page.button13}}</a>
            <a href="#" class="btn btn-secondary my-2">{{page.button2}}</a>
          </p>
        </div>
      </section>

  <div class="container">
      <div class="row">
        <div class="col-lg-6">{{page.img1 | img}} {{page.introlinks | textarea}}</div>
        <div class="col-lg-6">{{page.introrechts | textarea}}</div>
      </div>
      <br>
    </div>



    <?php include("footer.php")?>
