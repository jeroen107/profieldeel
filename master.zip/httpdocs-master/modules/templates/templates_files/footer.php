</div>

<footer>
    This is where the footer lives
    {{template.facebooklink}}
    {{template.twitterlink}}

  {{template.logofooter | image}}
    {{template.overons | textarea}}
<?php
echo "{{template.instagramlink}}";
?>

</footer>

</body>
</html>
